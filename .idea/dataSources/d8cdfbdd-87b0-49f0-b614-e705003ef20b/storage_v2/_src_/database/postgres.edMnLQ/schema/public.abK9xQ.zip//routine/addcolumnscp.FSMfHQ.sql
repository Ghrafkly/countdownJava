create procedure addcolumnscp(IN column_name character varying)
    language plpgsql
as
$$
DECLARE
    i INTEGER;
BEGIN
    FOR i IN 1..720 LOOP
        EXECUTE 'ALTER TABLE combinations_permutations ADD COLUMN ' || column_name || i || ' VARCHAR(10) UNIQUE';
    END LOOP;
END;
$$;

alter procedure addcolumnscp(varchar) owner to postgres;

