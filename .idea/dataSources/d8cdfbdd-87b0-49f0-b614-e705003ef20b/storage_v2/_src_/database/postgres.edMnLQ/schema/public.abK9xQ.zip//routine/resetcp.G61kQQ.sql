create procedure resetcp()
    language sql
as
$$
    DROP TABLE IF EXISTS combinations_permutations;
    CREATE TABLE combinations_permutations (
        combination INTEGER NOT NULL
    );
$$;

alter procedure resetcp() owner to postgres;

